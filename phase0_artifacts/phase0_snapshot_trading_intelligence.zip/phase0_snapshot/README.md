# Trading Intelligence & Research Platform

## Vision

This project is a **Trading Intelligence & Self-Learning Analytics Platform**.

It does **not trade**, does **not place orders**, and does **not control execution**.

Instead, it focuses on:
- Understanding real trading behavior
- Analyzing real market outcomes
- Learning daily from executed trades
- Providing clear, explainable trading insights

> The trader decides.  
> Bots execute experiments.  
> The platform thinks, learns, and explains.

---

## Core Principles

- ❌ No trade execution
- ❌ No order placement
- ❌ No SL / TP management
- ❌ No automated decision making
- ✔ Read-only data access
- ✔ Reality-based learning
- ✔ Human-in-the-loop by design

This platform exists to **improve decision quality**, not to automate risk.

---

## What Problem This Solves

Most trading systems fail because they:
- Learn from unrealistic backtests
- Ignore trader behavior
- Confuse luck with skill
- Execute without understanding

This platform solves that by turning **real trading history** into **structured intelligence**.

---

## System Overview

The system is composed of **two strictly separated layers**.

### 1. Trading Execution Layer (External)

- Manual trading by the user  
- One or more independent trading bots  
- Bots may operate on:
  - Binance Testnet
  - Binance Paper Trading

This layer is **not part of this project**.

---

### 2. Trading Intelligence System (This Project)

This project:
- Collects executed trades (read-only)
- Enriches trades with market context
- Analyzes trader behavior and strategy patterns
- Learns daily from real outcomes
- Produces insights, probabilities, and scenarios

---

## Data Sources

- Binance account trade history (read-only)
- Market data at time of execution
- Bot-provided trade facts (via data contract)
- Derived performance and behavior metrics

> Backtests are intentionally excluded.

---

## Analytics Levels

The platform operates across **five analytics levels**:

1. **What Happened**
   - PnL, Win Rate, Drawdown, Equity Curve

2. **Why It Happened**
   - Market conditions
   - Strategy context
   - Trader behavior

3. **What Usually Happens**
   - Probabilities
   - Expected value
   - Pattern statistics

4. **What Should Be Considered**
   - Risk awareness
   - Strategy suitability
   - Behavioral warnings

5. **What Could Happen**
   - Best / Base / Worst case scenarios
   - Outcome distributions
   - Confidence bands

---

## Daily Learning Loop

Every day, after trading ends:

1. Trade data is frozen
2. Features are extracted
3. Behavior metrics are analyzed
4. Patterns are learned
5. Scenarios are updated
6. Insights and reports are generated

Learning is **post-trade only**.

---

## Trading Bots Integration

Trading bots are treated as **experiment generators**, not decision makers.

The platform can:
- Compare bot vs bot
- Compare bot vs manual trading
- Compare strategy versions
- Detect strategy degradation

Bots never receive commands from this system.

---

## Dashboard Philosophy

The dashboard is designed to answer questions, not to impress visually.

Key views:
- Overview (performance & stability)
- Trader behavior (discipline & psychology)
- Strategy & pattern analysis
- Scenario & probability analysis
- Daily learning insights
- Bot intelligence & comparison
- System health & trust

Each page answers **one clear question**.

---

## System Health & Trust

The system continuously monitors itself:
- Data integrity
- Pipeline health
- Logic validity
- Model confidence

A **Trust Score** is calculated and displayed.

If trust is low:
- Recommendations are reduced or disabled
- Only raw data is shown

> If the system is not confident, it must say so.

---

## Execution Readiness & Governance

### Current State: Execution Disabled

Trading execution is **intentionally disabled by design**.

- ❌ No order placement
- ❌ No execution modules
- ❌ No trading API permissions
- ❌ No actionable order payloads

All outputs are analytical only.

---

### Architectural Lock

Execution is prevented at multiple levels:
- No execution-related code exists
- One-way data flow is enforced
- Intelligence never controls execution

Even in case of bugs or misconfiguration, the system **cannot place trades**.

---

### Future Enablement (Explicit Governance Only)

Execution may only be enabled in a future version if:

1. A separate execution layer is implemented
2. New API keys with limited permissions are used
3. Risk limits and kill-switches are enforced
4. Paper trading validation is completed
5. Explicit human approval is given

No automatic activation is allowed.

---

### Human-in-the-Loop Mandate

Even if execution is enabled in the future:
- The system may recommend but never decide autonomously
- A human must explicitly enable and disable execution
- Emergency shutdown must always be available

---

## Project Structure (High Level)


---

## Intended Users

- Serious discretionary traders
- Algorithmic traders testing strategies
- Quant-curious developers
- Anyone who wants to turn real trading into real skill

---

## Final Note

This is not a trading bot.  
This is not a signal service.

This is a **thinking layer** — a system that understands:
- The market
- The trader
- The strategy
- And its own limitations

> Understanding comes before execution.  
> Learning comes before automation.  
> Safety comes before speed.
install this in dashboard folder 
npm install axios @mui/material @mui/icons-material @emotion/react @emotion/styled plotly.js react-plotly.js
